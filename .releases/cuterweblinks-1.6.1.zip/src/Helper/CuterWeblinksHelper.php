<?php
/**
 * @package    TheLoom.Module.CuterWeblinks
 *
 * @author     Stefan <schulz@the-loom.de>
 * @copyright  Copyright (C) 2026 The Loom / Stefan Schulz
 * @license    GNU General Public License version 3 or later; see LICENSE.txt
 * @link       https://www.the-loom.de
 */

namespace TheLoom\Module\CuterWeblinks\Site\Helper;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Router\Route;
use Joomla\Registry\Registry;

defined('_JEXEC') or die;

/**
 * Helper for mod_cuterweblinks
 *
 * @since 1.0
 */
class CuterWeblinksHelper
{

    /**
     * Retrieve list of links from Weblinks.
     *
     * @param Registry $params The module parameters
     * @param CMSApplicationInterface $app The application
     *
     * @return mixed An array of links or {@code null}, if no links were found.
     *
     * @since 1.0
     **/
    public static function getLinks(Registry $params, CMSApplicationInterface $app): mixed
    {
        // Determine required fields and parameters
        $fields = ['weblinks.id', 'weblinks.title', 'weblinks.url'];
        if ($params->get('image', false)) {
            $fields[] = 'weblinks.images';
        }
        if ($params->get('hits', false)) {
            $fields[] = 'weblinks.hits';
        }
        if ($params->get('description', false)) {
            $fields[] = 'weblinks.description';
        }
        $categories = array_unique($params->get('categories', ['all']));
        $listAllCategories = in_array('all', $categories);
        if (!$listAllCategories) {
            $fields[] = 'weblinks.catid';
        }
        $limit = $params->get('count', 5);
        $ordering = $params->get('ordering', 'title');
        $direction = $params->get('direction', 'ASC');
        $respectLanguages = $params->get('languages');

        // Setup and run DB query
        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true);
        $query->select($db->quoteName($fields));
        if ($params->get('category', false)) {
            $query->select($db->quoteName('categories.title', 'category'));
        }
        $query->from($db->quoteName('#__weblinks', 'weblinks'));
        $query->leftJoin(
            $db->quoteName('#__categories', 'categories')
            . ' ON ' . $db->quoteName('categories.id') . ' = ' . $db->quoteName('weblinks.catid')
        );
        $query->where($db->quoteName('weblinks.state') . ' = 1');
        $query->where($db->quoteName('categories.published') . ' = 1');
        $authorisedViewLevels = $app->getIdentity()->getAuthorisedViewLevels();
        $query->whereIn($db->quoteName('weblinks.access'), $authorisedViewLevels);
        $query->whereIn($db->quoteName('categories.access'), $authorisedViewLevels);
        if (!$listAllCategories) {
            $query->where($db->quoteName('weblinks.catid') . ' IN (' . implode(',', $categories) . ')');
        }
        if ($respectLanguages) {
            $query->where($db->quoteName('weblinks.language') . ' IN (' . $db->quote($app->getLanguage()->getTag()) . ',' . $db->quote('*') . ')');
        }
        if (is_numeric($limit)) {
            $query->setLimit(intval($limit));
        }
        $query->order($db->quoteName('weblinks.' . $ordering) . ' ' . $direction);
        try {
            $db->setQuery($query);
            $links = $db->loadObjectList();
        } catch (\RuntimeException $exception) {
            // Catches Joomla's ExecutionFailureException/PrepareStatementFailureException as well as
            // a native mysqli_sql_exception (PHP's default mysqli error mode since 8.1) - which concrete
            // type surfaces depends on the driver/PHP version, so the common RuntimeException ancestor
            // is caught instead of enumerating them. Weblinks may be enabled in the extensions registry
            // but its tables missing or broken (e.g. an interrupted uninstall) - skip the module instead
            // of taking down the whole page.
            Log::add('CuterWeblinksHelper: failed to query weblinks - ' . $exception->getMessage(), Log::WARNING, 'mod_cuterweblinks');
            return null;
        }
        // postprocessing results to clean up title, determine target reference and resolve image url
        if (!empty($links)) {
            foreach ($links as $link) {
                $link->title = strip_tags($link->title);
                if (isset($link->description)) {
                    $trim = (int) $params->get('description_trim', 0);
                    if ($trim > 0) {
                        // block-level tags become a space first, otherwise strip_tags() glues
                        // adjacent paragraphs together ("...end.</p><p>Next" -> "...end.Next");
                        // inline tags (<b>, <a>, ...) are removed without one so words stay whole
                        $html = preg_replace('/<\/?(?:p|div|br|hr|li|ul|ol|h[1-6]|table|tr|td|th|blockquote|pre)\b[^>]*>/i', ' ', $link->description);
                        $plain = trim(preg_replace('/\s+/', ' ', strip_tags($html)));
                        if (mb_strlen($plain) > $trim) {
                            // cut at the last whole word within the limit, then ellipsis
                            $cut = mb_substr($plain, 0, $trim);
                            $lastSpace = mb_strrpos($cut, ' ');
                            if ($lastSpace !== false) {
                                $cut = mb_substr($cut, 0, $lastSpace);
                            }
                            $plain = rtrim($cut) . '…';
                        }
                        $link->description = $plain;
                    }
                }
                $link->reference = Route::_('index.php?option=com_weblinks&task=weblink.go&id=' . $link->id);
                $link->imageUrl = null;
                if (!empty($link->images)) {
                    $imgContainer = json_decode($link->images);
                    $url = null;
                    if (!empty($imgContainer->image_first)) {
                        $url = $imgContainer->image_first;
                    } elseif (!empty($imgContainer->image_second)) {
                        $url = $imgContainer->image_second;
                    }
                    if (!empty($url)) {
                        $joomlaImageStart = strpos($url, '#');
                        if ($joomlaImageStart !== false) {
                            $url = substr($url, 0, $joomlaImageStart);
                        }
                        $link->imageUrl = $url;
                    }
                }
            }
        }
        return $links;
    }

    /**
     * Determine the layout-related stylesheet, if it exists.
     *
     * @param $module string This module.
     * @param $layout string The layout to be applied.
     * @return string|null The resulting style filename or <code>null</code>.
     *
     * @since 1.0
     */
    public static function getStyleFilename(string $module, string $layout = 'default'): ?string
    {
        if (str_contains($layout, ':')) {
            // Get the template and file name from the string
            [, $layout] = explode(':', $layout);
        }
        $basePath = 'media/' . $module . '/css/';
        $fileName = $basePath . $layout . '_style.css';
        if (file_exists(JPATH_ROOT . '/' . $fileName)) {
            return $fileName;
        }
        $fileName = $basePath . 'default_style.css';
        if (file_exists(JPATH_ROOT . '/' . $fileName)) {
            return $fileName;
        }
        return "";
    }

}